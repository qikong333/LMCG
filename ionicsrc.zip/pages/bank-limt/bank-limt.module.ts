import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BankLimtPage } from './bank-limt';

@NgModule({
  declarations: [
    BankLimtPage,
  ],
  imports: [
    IonicPageModule.forChild(BankLimtPage),
  ],
})
export class BankLimtPageModule {}
