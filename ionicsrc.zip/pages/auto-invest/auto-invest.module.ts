import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AutoInvestPage } from './auto-invest';

@NgModule({
  declarations: [
    AutoInvestPage,
  ],
  imports: [
    IonicPageModule.forChild(AutoInvestPage),
  ],
})
export class AutoInvestPageModule {}
