import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SetLockPage } from './set-lock';

@NgModule({
  declarations: [
    SetLockPage,
  ],
  imports: [
    IonicPageModule.forChild(SetLockPage),
  ],
})
export class SetLockPageModule {}
