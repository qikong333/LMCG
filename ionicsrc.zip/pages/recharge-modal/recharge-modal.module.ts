import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RechargeModalPage } from './recharge-modal';

@NgModule({
  declarations: [
    RechargeModalPage,
  ],
  imports: [
    IonicPageModule.forChild(RechargeModalPage),
  ],
})
export class RechargeModalPageModule {}
