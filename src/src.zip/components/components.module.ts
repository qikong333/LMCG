import { NgModule } from '@angular/core';
import { IonMeterComponent } from './ion-meter/ion-meter';
import { IonicModule } from 'ionic-angular/module';
@NgModule({
	declarations: [IonMeterComponent],
	imports: [IonicModule],
	exports: [IonMeterComponent]
})
export class ComponentsModule {}
