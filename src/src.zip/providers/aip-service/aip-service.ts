import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { HttpServiceProvider } from '../http-service/http-service';
import { SERVER_URL } from '../constants/constants';
 

@Injectable()
export class AipServiceProvider {

  constructor(public http: HttpServiceProvider) {
    console.log('Hello AipServiceProvider Provider');
  }


  /**
* @name  
*/
  timing() {
    return this.http.postFormData('app/timing.htm')
  }


}
