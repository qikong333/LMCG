import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MoreBulletinPage } from './more-bulletin';

@NgModule({
  declarations: [
    MoreBulletinPage,
  ],
  imports: [
    IonicPageModule.forChild(MoreBulletinPage),
  ],
})
export class MoreBulletinPageModule {}
