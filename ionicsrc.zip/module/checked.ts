export class CheckesModule {
    checked: boolean
    value:any
}