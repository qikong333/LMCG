import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NeverNetworkPage } from './never-network';

@NgModule({
  declarations: [
    NeverNetworkPage,
  ],
  imports: [
    IonicPageModule.forChild(NeverNetworkPage),
  ],
})
export class NeverNetworkPageModule {}
