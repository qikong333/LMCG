import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { HytjPage } from './hytj';

@NgModule({
  declarations: [
    HytjPage,
  ],
  imports: [
    IonicPageModule.forChild(HytjPage),
  ],
})
export class HytjPageModule {}
