
// 初始化

// export const SERVER_URL = 'https://www.rongyudai.cn/'  //正式地址
export const SERVER_URL = 'http://rydvpn.sedns.cn:89/'  //测试地址~
// export const  SERVER_URL = 'http://192.168.3.140:8080/'//景亮地址
// export const SERVER_URL = 'http://192.168.3.54:8080/'  //学良地址
// export const SERVER_URL = 'http://192.168.3.250:8080/'  //建华地址


export const APP_NUM = 1;//APP版本id

export const VERSION_NUM = '3.0.0';//APP版本号

export const PAGE_SIZE = 5; //默认分页大小

export const REQUEST_TIMEOUT = 12000;//请求超时时间,单位为毫秒

// export const ADNROID_APK = 'http://172.16.19.86/kit_file_server/file/android-test.apk';//android apk下载完整地址
export const ADNROID_APK = 'http://www.jiuxiangdai.cn/download//home/cf_home/download/android.apk';//android apk下载完整地址


export const APK_DOWNLOAD = 'http://omzo595hi.bkt.clouddn.com/ionic2_tabs.apk';//android apk下载完整地址,用于android本地升级
export const APP_DOWNLOAD = 'http://omzo595hi.bkt.clouddn.com/download.html';//app网页下载地址,用于ios升级或android本地升级失败

  