import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NavtitleWeChatPage } from './navtitle-we-chat';

@NgModule({
  declarations: [
    NavtitleWeChatPage,
  ],
  imports: [
    IonicPageModule.forChild(NavtitleWeChatPage),
  ],
})
export class NavtitleWeChatPageModule {}
